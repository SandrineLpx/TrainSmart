---
name: weekly-plan
description: Plan your training week. Sets how many days you'll train, picks the best days based on weather and schedule, and saves a tentative plan. Use at the start of each week (Sunday/Monday).
---

# Weekly Planner

Review last week, ask schedule preferences, build day-by-day schedule (WL + cardio), save to `data/current_week_plan.json`.

## Inputs

- Athlete inputs: available training days, outdoor cardio preference, fatigue/pain
- Competition date confirmation/update from `data/preferences.json`
- Program/training context: `data/program.json`, `data/training_log.ndjson`, `data/prs.json`
- External context: weather forecast and Strava recent activities (if available)

## Outputs

- Weekly schedule response (day-by-day WL/cardio plan + rationale)
- Saved/updated `data/current_week_plan.json` including `program_name` and `total_weeks`

## Workflow

### Step 0: Check for competition date

Before asking anything, read `data/preferences.json` and check for a `competition_date` field.

- **If a competition date exists:** Show it to the athlete and ask to confirm it's still correct. Also ask if there are any other competitions or events before that date.
- **If no competition date exists:** Ask if there's a competition within the next 4 weeks. If yes, save the date to `data/preferences.json` as `competition_date` (ISO format).

### Step 1: Ask the athlete (all at once)

```
Quick weekly planning:
1. Which days are you training this week? (e.g., "Tue, Thu, Sat" or "none")
2. Want to plan outdoor cardio? (yes/no — I'll check weather)
3. How are you feeling? Fatigue: low/medium/high, any pain?
```

Note: Competition question is handled in Step 0 — do NOT ask again here.

### Step 2: Gather data (in parallel)

1. **Last week's log** → Read `data/training_log.ndjson`. Summarize: sessions done, exercises completed vs. skipped, cardio, RPE avg, soreness trend.
2. **Program** → Read `data/program.json`. Calculate week number per CLAUDE.md formula. Look up prescribed exercises for all 5 days.
3. **PRs** → Read `data/prs.json`. Used in Step 3 to compute target weights per CLAUDE.md "Weight Guidance".
4. **Weather** (days=7) → Identify outdoor-suitable days per CLAUDE.md "Weather Preferences". Rank by quality.
5. **Strava** (days_back=7) → Classify per CLAUDE.md "Strava Activity Types".

After loading data, do a quick log-completeness check (no hard block):
- **If Strava is available:** Cross-check last week's Strava activities against `training_log.ndjson`. If likely training sessions are missing from the log, ask: "I found sessions in Strava that are not logged. Do you want to log any now before planning, or continue?"
- **If Strava is unavailable/not configured:** Ask: "Are last week's training days accurately logged, or do you want to add anything before I plan this week?"
- In both cases, athlete chooses whether to add info now or continue planning. Never block `/weekly-plan`.

### Step 3: Build the schedule

Assign T/S/H/Hybrid per CLAUDE.md "T/S/H Session System". Priority when fewer than 5 days: T → S → H. (0=rest, 1=T, 2=T+S, 3=T+S+H, 4=+Hybrid, 5=full week). If the heavy-work recency trigger in CLAUDE.md is met, prioritize H over S.

**Intensity:** default normal. Use condensed to pull 1-2 priority exercises from skipped days (cut accessories, max ~6 per session). Use light/mini when fatigued. See condensed example in `references/skill_schemas.md`.

**Weights:** For each exercise with a matching PR in `prs.json`, compute target weight range per CLAUDE.md "Weight Guidance" and show it inline (e.g., `Front Squat 5x5 @56-60kg`).

**Spacing:** ≥1 rest day between sessions when possible. Note carry-overs from last week.

**Cardio:** place on weather-suitable non-WL days. Bike Z2 OK adjacent to T/S. Hard run/ski never before H or heavy S.

**Competition taper:** D-10→D-5: reduce volume 20-40%. D-4→D-2: light technique. D-1: mini-T/mobility.

**Fatigue:** Apply CLAUDE.md readiness rules to select mini/standard/full intensity.

### Step 4: Save the plan

Read then overwrite `data/current_week_plan.json`. Include `program_name` and `total_weeks` from program.json so `/checkin` can skip reading the program file. Schema in `references/skill_schemas.md`.

### Step 5: Output

Format per template in `references/skill_schemas.md`. Display temperatures as °C (°F) per CLAUDE.md.


## Failure Modes and Fallbacks

- Weather unavailable: plan with log/program data only and skip weather ranking
- Strava unavailable/not configured: ask about recent cardio or rely on training log
- Missing/limited recent logs: continue planning from program + athlete inputs
- Conflicting availability constraints: prioritize requested WL day count and preserve T/S/H ordering

## Constraints

- Never schedule more WL days than requested
- Always save to `data/current_week_plan.json` with `program_name` + `total_weeks`
- Maximum 1 protection rule
- Schedule is a suggestion — athlete can move sessions
- If weather/Strava unavailable, skip or use log data only
- Log-completeness checks are advisory only (user choice, no hard-block)
